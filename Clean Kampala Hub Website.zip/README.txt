CleanKampala Hub website prototype

Files:
- index.html: semantic HTML5 page
- style.css: responsive styling

How to use:
1. Keep index.html and style.css in the same folder.
2. Open index.html in a modern web browser.
3. Edit the HTML content and CSS styles as needed.

Standards and accessibility:
- HTML5 semantic landmarks and a declared English language
- Responsive viewport metadata
- Labels associated with form controls
- Keyboard-visible focus styles and skip link
- Reduced-motion preference support
- No external libraries or frameworks

Important:
This is a static front-end prototype. Report submission, reference-number tracking,
collector lookup, and feedback delivery require a secure back-end/API connection.
The collector directory and collection schedules were not supplied in the source report,
so the website explains that residents should verify those details with KCCA or their
licensed collector. Fee examples and waste statistics are reproduced from the report.
